#ifndef WEBQUERY_HPP
#define WEBQUERY_HPP

#include <iostream>
#include <map>
#include <sstream>
#include "filesystem.hpp"

class Webquery {
	private:
		Filesystem fs;
		std::string dir = fs.getCurrentPath();
		
	public:
		Webquery() {}
		strSet getPagesWord(std::string keyword);
		strSet getTitlesWord(std::string keyword);
		int getLinksLink(std::string link);
		
		strSet getAllURLs();		
		
		std::map<std::string, int> calculateRelevance(std::string keyword);
};

#endif
