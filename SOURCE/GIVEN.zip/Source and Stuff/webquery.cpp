#include "webquery.hpp"

using std::string;
using std::map;
using std::ifstream;

/*
 * Flips an std::pair<A, B> to std::pair<B, A>.
 * Credit goes to Oliver CharlesWorth 
 * (http://stackoverflow.com/a/5056797/1762311)
 */
template<typename A, typename B>
std::pair<B,A> flip_pair(const std::pair<A,B> &p) {
    return std::pair<B,A>(p.second, p.first);
}

/*
 * Flips an std::map<A, B> to std::map<B, A>.
 * Credit goes to Oliver CharlesWorth 
 * (http://stackoverflow.com/a/5056797/1762311)
 */
template<typename A, typename B>
std::multimap<B,A> flip_map(const std::map<A,B> &src) {
    std::multimap<B,A> dst;
    std::transform(src.begin(), src.end(), std::inserter(dst, dst.begin()), 
                   flip_pair<A,B>);
    return dst;
}

/*
 * Get all urls that contain given word on their page.
 */
strSet Webquery::getPagesWord(string keyword) {
	string pagedir = dir + "/pageindex/", pagefile, line;
	ifstream ifs;
	strSet pages;
	if(fs.checkDir(pagedir)) {
		pagefile = pagedir + keyword;
		ifs.open(pagefile);
		while(getline(ifs, line)) { pages.insert(line); }
		ifs.close();
	}
	return pages;
}

/*
 * Get all the urls that contain given word in their title.
 */
strSet Webquery::getTitlesWord(string keyword) {
	string titledir = dir + "/titleindex/", titlefile, line;
	ifstream ifs;
	strSet titles;
	if(fs.checkDir(titledir)) {
		titlefile = titledir + keyword;
		ifs.open(titlefile);
		while(getline(ifs, line)) { titles.insert(line); }
		ifs.close();
	}
	return titles;
}

/*
 * Get the amount of links that link to the given url.
 */
int Webquery::getLinksLink(string link) {
	string hashedLink = fs.createMD5(link);
	string linkdir = dir + "/linkindex/", linkfile, line;
	strSet links;
	ifstream ifs;
	if(fs.checkDir(linkdir)) {
		linkfile = linkdir + hashedLink;
		ifs.open(linkfile);
		while(getline(ifs, line)) { links.insert(line); }
		ifs.close();
	}
	return links.size();
}

/*
 * Content of the file "allLinks" in the directory 
 * "/repository/" is stored in a strVec, which is then returned.
 */
strSet Webquery::getAllURLs() {
	string linkdir = dir + "/repository/", line;
	strSet allURLs;
	ifstream ifs;
	if(fs.checkDir(linkdir)) {
		ifs.open(linkdir + "allLinks");
		while(getline(ifs, line)) { allURLs.insert(line); }
		ifs.close();
	}
	return allURLs;
}

/* 
 * Calculate the relevance of all applicable urls for given keyword.
 * For each url found with the spider, give basic relevancy 1.
 * If it has given keyword in title, give it 16 more relevancy.
 * For having the keyword in the page, 4 relevancy.
 * For each link linking to the current link: 1 relevancy.
 * Return then each url with it's relevancy.
 */
map<string, int> Webquery::calculateRelevance(string keyword) {
	strSet sitesWithPageWord = getPagesWord(keyword);
	strSet sitesWithTitleWord = getTitlesWord(keyword);
	map<string, int> relevances;
	int currentRelevance;
	
	for(auto page : getAllURLs()) {
		currentRelevance = 1;
		if(sitesWithTitleWord.find(page) != sitesWithTitleWord.end()) 
			{ currentRelevance += 160; }
		if(sitesWithPageWord.find(page) != sitesWithPageWord.end())
			{ currentRelevance += 40; }
		currentRelevance += getLinksLink(page);
		relevances[page] = currentRelevance;
	}
	return relevances;
}

/*
 * Print the list of URLs found by the spider, sorted along their
 * relevance to the keyword.
 */
int main(int argc, char *argv[]) {
	string keyword;
	Webquery wq;
	typedef std::multimap<int, string>::reverse_iterator MapIterator;
	int amountOfResults = 50, currentAmount = 0;
	
	if(argc < 2) { std::cout << "Please give a keyword!" << std::endl; exit(0); }
	keyword = argv[1];
	if(argc >= 3) { 
		std::istringstream iss(argv[2]);
		if(!(iss >> amountOfResults)) { 
			std::cerr << "Invalid amount of results given: " << argv[2] << std::endl;
			amountOfResults = 50;
		}
	}
	
	map<string, int> results = wq.calculateRelevance(keyword);
	std::multimap<int, string> sortedResults = flip_map(results);
	
	for(MapIterator rel = sortedResults.rbegin(); rel != sortedResults.rend(); rel++ ) { 
		std::cout << rel->second << std::endl;
		if(++currentAmount >= amountOfResults) { break; }
	}
	return 0;
}
