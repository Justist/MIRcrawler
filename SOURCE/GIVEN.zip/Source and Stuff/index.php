#!/usr/bin/php5-cgi
<html><body><center><p><br><p><br>

<font face=arial size=7 color=darkblue>LIACS Search</font>
<p>
<form enctype="multipart/form-data" action="./searchpage.php" method="post">
	<input name="myquery" size="60">
	<input name="search" value="Search!" type="submit"> 
</form>

</center></body></html>
