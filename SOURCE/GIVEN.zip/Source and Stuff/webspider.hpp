#ifndef WEBSPIDER_HPP
#define WEBSPIDER_HPP

#include <cstring>
#include <stdio.h>
#include <vector>
#include <iostream>

#include "filesystem.hpp"

extern "C" { 
	#include "../title/htmlstreamparser.h" 
	#include <curl/curl.h>
	#include <malloc.h>
}

#define MAXQSIZE 9000000       // Maximum size of the queue, q
#define MAXURL 100000          // Maximum size of a URL
#define MAXPAGESIZE 20000          // Maximum size of a webpage
#define MAXDOWNLOADS 2000      // Maximum number of downloads we will attempt

#endif
