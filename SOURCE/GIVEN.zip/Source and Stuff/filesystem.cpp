#include "filesystem.hpp"

using std::string;
using std::cout;
using std::endl;

/*
 * Checks if a given dir exists.
 * If so, return true, else false.
 */
bool Filesystem::checkDir(string dir) {
	DIR *tdir = opendir(dir.c_str());
	if(tdir == NULL) return false;
	closedir(tdir);
	return true;
}

/*
 * Make a dir with given name.
 * Will not try to if dir already exists.
 * If dir is made successfully, return true, else false.
 */
bool Filesystem::makeDir(string dirToMake) {
	int err = 0;
	if(!checkDir(dirToMake)) {
		// RW permissions for user and group, RX for others
		err = mkdir(dirToMake.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	}
	if(err == 0) return true;
	return false;
}

/*
 * Retrieve the absolute path the executable is running from.
 * If getcwd fails, assume "." will be expanded by the filesystem when used.
 */
string Filesystem::getCurrentPath() {
	char cp[FILENAME_MAX];
	if(getcwd(cp, sizeof(cp))) return string(cp);
	return ".";
}

/*
 * Calculate the MD5 of a string.
 * Credit goes to The Quantum Physicist (http://stackoverflow.com/q/31166313/1762311)
 */
string Filesystem::createMD5(string orig) {
	unsigned char result[MD5_DIGEST_LENGTH];
	MD5((unsigned char*) orig.c_str(), orig.size(), result);

	std::ostringstream sout;
	sout << std::hex << std::setfill('0');
	for(long long c: result)
	{
		 sout << std::setw(2) << (long long) c;
	}
	return sout.str();
}

/*
 * Split a string based on certain characters to split on.
 * All splitted strings are stored in a strVec which is 
 * then returned.
 */
strVec Filesystem::splitString(string orig) {
	string token = "";
	strVec tokens;
	char current;
	for(unsigned int i = 0; i < orig.length(); i++) {
		current = orig[i];
		if(current != ' ' && current != '\n' && current != '.') { token += orig[i]; }
		else { tokens.push_back(token); token = ""; }
	}
	return tokens;
}

/*
 * Converts each weblink to an MD5, then creates files with these codes as names.
 * Then print the link of the current page in each of these files.
 */
void Filesystem::createLinkIndex(string link, strVec weblinks) {
	string newdir = dir + "/linkindex/";
	std::ofstream ofs;
	if(makeDir(newdir)) {
		for(auto weblink: weblinks) {
			ofs.open(newdir + createMD5(weblink), std::ofstream::out | std::ofstream::app);
			ofs << link << endl;
			ofs.close();
		}
	}
}

/*
 * Check if given string contains only alphanumeric characters.
 * If so, return true, else false.
 */
bool Filesystem::checkKeyword(string keyword) {
	for(char k : keyword) { if(!isalpha(k)) { return false; } }
	return true;
}

/*
 * Create an inverse index based on the title.
 */
void Filesystem::createTitleIndex(string link, string title) {
	string newdir = dir + "/titleindex/";
	std::ofstream ofs;
	if(makeDir(newdir)) {
		for(string keyword : splitString(title)) {
			if(!checkKeyword(keyword)) { continue; }
			ofs.open(newdir + keyword, std::ofstream::out | std::ofstream::app);
			ofs << link << endl;
			ofs.close();
		}
	}
}

/*
 * Create an inverse index based on the page contents.
 * First a string is made of all the words in the file,
 * which then all words are taken out of and made as files.
 * Known bug: If a page contains a word multiple times,
 * the file of that word contains the same link multiple times.
 */
void Filesystem::createPageIndex(string link, string html) {
	string wordString = "";
	int inTag = 0;
	for(size_t i = 0; i < html.length(); i++) {
		if(html[i] == '<') { inTag++; wordString += " "; }
		else if(inTag > 0 && html[i] == '>') { inTag--; }
		else if(inTag == 0) { wordString += html[i]; }
	}
	
	string newdir = dir + "/pageindex/";
	std::ofstream ofs;
	if(makeDir(newdir)) {
		for(string keyword : splitString(wordString)) {
			if(!checkKeyword(keyword)) { continue; }
			ofs.open(newdir + keyword, std::ofstream::out | std::ofstream::app);
			ofs << link << endl;
			ofs.close();
		}
	}
}

/*
 * Deposit the sites as html in a folder 'repository'.
 * It also creates a file which contains all urls processed.
 */
void Filesystem::fillRepository(string link, string html) {
	string newdir = dir + "/repository/";
	std::ofstream ofs;
	if(makeDir(newdir)) {
		ofs.open(newdir + createMD5(link), std::ofstream::out | std::ofstream::trunc);
		ofs << html << endl;
		ofs.close();
		
		ofs.open(newdir + "allLinks", std::ofstream::out | std::ofstream::app);
		ofs << link << endl;
		ofs.close();
	}
}
