#!/usr/bin/php5-cgi
<html><body><center><p><br><p><br><font face=arial>

<font size=7 color=darkblue>LIACS Search</font>
<p>
<form enctype="multipart/form-data" action="./searchpage.php" method="post">
<input name="myquery" size="60">
<input name="Search" value="Search!" type="submit"> </form>
<p><br><p></center>
<?php

echo '<hr><p><font size=6 color=darkblue>Results</font><p>';

// $myquery contains the query from the search engine
$myquery = escapeshellarg($_POST['myquery']); 

//Using backticks one way for PHP to call an external program and return the output
$myoutput = `./webquery $myquery`;

$array = explode("\n", $myoutput);
$i = 1;
foreach($array as $url) {
	if($url == "") continue;
	echo "(".$i.") <a href = " . $url . " > " . $url . "</a><br/><br/>";
	$i++;
}
?>

</font></body></html>
