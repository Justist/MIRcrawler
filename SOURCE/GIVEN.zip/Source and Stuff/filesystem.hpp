#ifndef FILESYSTEM_HPP
#define FILESYSTEM_HPP

#include <iostream>
#include <sstream>
#include <fstream>
#include <cstring>
#include <vector>
#include <iomanip> 
#include <algorithm>
#include <unordered_set>

extern "C" {
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <dirent.h>
	#include <stdio.h>
	#include <unistd.h>
	#include <openssl/md5.h>
}

typedef std::vector<std::string> strVec;
typedef std::unordered_set<std::string> strSet;

class Filesystem {
	private:
		std::string dir = getCurrentPath();
		
		bool makeDir(std::string dir);
		strVec splitString(std::string orig);
		bool checkKeyword(std::string keyword);
	
	public:
		Filesystem() {}
		
		std::string getCurrentPath();
		bool checkDir(std::string dir);
		std::string createMD5(std::string orig);
		
		void createLinkIndex(std::string link, strVec weblinks);
		void createTitleIndex(std::string link, std::string title);
		void createPageIndex(std::string link, std::string html);
		void fillRepository(std::string link, std::string html);
};

#endif
