#ifndef FILESYSTEM_HPP
#define FILESYSTEM_HPP

#include "includes.hpp"

class Filesystem {
	private:
		std::string dir = getCurrentPath();
		
		bool makeDir(std::string dir);
		strVec splitString(std::string orig);
		bool checkKeyword(std::string keyword);
	
	public:
		Filesystem() {}
		
		std::string getCurrentPath();
		bool checkDir(std::string dir);
		bool fileExist(std::string filename);
		bool linkExistRepo(std::string link);
		void removeIndexDups(std::string filename);
		std::string createMD5(std::string orig);
		
		void createLinkIndex(std::string link, strSet weblinks);
		void createTitleIndex(std::string link, std::string title);
		void createPageIndex(std::string link, std::string html);
		void fillRepository(std::string link, std::string html);
};

#endif
