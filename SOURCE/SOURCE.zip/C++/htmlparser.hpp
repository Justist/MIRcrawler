#ifndef HTMLPARSER_HPP
#define HTMLPARSER_HPP

#include "includes.hpp"

class Htmlparser {
	private:
		std::string checkLink(std::string link, std::string origUrl);
	public:
		Htmlparser() { }
		~Htmlparser() { }
		
		strSet parseLinks(std::string source, std::string origUrl);
		std::string parseTitle(std::string source);
};

#endif
