#ifndef WEBSPIDER_HPP
#define WEBSPIDER_HPP

#include "filesystem.hpp"
#include "hspfunctions.hpp"
#include "htmlparser.hpp"

#define MAXQSIZE 9000000		// Maximum size of the queue, q
#define MAXURL 100000			// Maximum size of a URL
#define MAXPAGESIZE 20000		// Maximum size of a webpage
#define MAXDOWNLOADS 3000			// Maximum number of downloads we will attempt

class Webspider {
	private:
		volatile int downloadsDone;
		std::vector<HTMLSTREAMPARSER *> hsps;
		std::vector<Htmlparser> htmlps;
		strDeq queue;
		std::mutex crawlMut;
		
		Hspfunctions hspfuncs;
		//Htmlparser htmlp;
		Filesystem fs;
		
		std::string takeFirstUrl();
		void AppendLinks(strSet weblinks);
		void doIndexing(std::string url, std::string html, strSet weblinks, std::string title);
	public:
		Webspider(std::string);
		
		void startCrawling(int threadNumber);
};

#endif
