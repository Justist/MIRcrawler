#include "threadspider.hpp"

using std::string;
using TCLAP::ValueArg;

Threadspider::Threadspider(int t, string s) : 
	numThreads(t), startingUrl(s), ws(s) {}

std::tuple<int, string> parseCmdArgs(int argc, char *argv[]) {
	try {
		TCLAP::CmdLine cmd("Crawls the web and searches for links, depending on the initial website given. "
								 "Isn't a real spider.", ' ', "0.5");
		ValueArg<string> urlArg("w", "website", "Website to start searching on.", true, "http://www.example.com", "string");
		ValueArg<int> threadArg("t", "threads", "Amount of threads to use.", false, 1, "int");
		
		cmd.add(urlArg);		
		cmd.add(threadArg);
		cmd.parse(argc, argv);
		
		string startingUrl = urlArg.getValue();
		int numThreads = threadArg.getValue();
		
		if(startingUrl.find("http") != string::npos) { printf("\nInitial web URL: %s\n\n", startingUrl.c_str()); }
		else { printf("\n\nError: You must start the URL with lowercase \"http://\".\n\n"); exit(0); }
		
		return std::make_tuple(numThreads, startingUrl);
		
	} catch(TCLAP::ArgException &e) {
		std::cerr << "Error: " << e.error() << " for arg " << e.argId() << std::endl;
	}
	
	return std::make_tuple(1, "Error Error Error!");
}

void Threadspider::startThreading() {
	int i;
	for(i = 0; i < numThreads; i++) {
		threads.emplace_back(std::thread(&Webspider::startCrawling, &ws, i));
	}
	for(i = 0; i < numThreads; i++) {
		threads.back().join();
		threads.pop_back();
	}
}

int main(int argc, char *argv[]) {
	int numThreads;
	string startingUrl;
	std::tie(numThreads, startingUrl) = parseCmdArgs(argc, argv);
	Threadspider ts(numThreads, startingUrl);
	ts.startThreading();
}
