#ifndef INCLUDES_HPP
#define INCLUDES_HPP

#include <algorithm>
#include <cstring>
#include <deque>
#include <fstream>
#include <iomanip> 
#include <iostream>
#include <map>
#include <mutex>
#include <sstream>
#include <stdio.h>
#include <tclap/CmdLine.h>
#include <thread>
#include <unordered_set>
#include <vector>

extern "C" {
	#include "../htmlstreamparser/htmlstreamparser.h"
	#include <curl/curl.h>
	#include <dirent.h>
	#include <malloc.h>
	#include <openssl/md5.h>
	#include <sys/stat.h>
	#include <stdio.h>
	#include <sys/types.h>
	#include <unistd.h>
}

typedef std::deque<std::string> strDeq;
typedef std::unordered_set<std::string> strSet;
typedef std::vector<std::string> strVec;

#endif
