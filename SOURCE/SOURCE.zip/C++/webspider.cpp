#include "webspider.hpp"

using std::string;
using std::deque;
using std::cout;
using std::endl;

Webspider::Webspider(string startingUrl) {
	queue.emplace_back(startingUrl);
}

/*
 * Append the weblinks to the end of the queue.
 * As that is easy, this function mainly checks for size problems.
 */
void Webspider::AppendLinks(strSet weblinks) {
	std::lock_guard<std::mutex> guard(crawlMut);
	if(queue.size() + weblinks.size() <= MAXQSIZE) { 
		for(auto w : weblinks) { 
			queue.emplace_back(w); 
		}
	}
	else { cout << "Queue is full!" << endl; }
}

/*
 * Call all the functions which do indexing.
 * We need to do indexing.
 */
void Webspider::doIndexing(string url, string html, strSet weblinks, string title) {
	std::lock_guard<std::mutex> guard(crawlMut);
	fs.createLinkIndex(url, weblinks);
	fs.createTitleIndex(url, title);
	fs.createPageIndex(url, html);
	fs.fillRepository(url, html);
}

/*
 * Take the first element of the queue, and then pop that element.
 * Thanks to the mutex, only one thread can do this at a time.
 */
string Webspider::takeFirstUrl() {
	std::lock_guard<std::mutex> guard(crawlMut);
	string firstUrl = "";
	if(!queue.empty()) {
		firstUrl = queue.front();
		queue.pop_front();
	}
	return firstUrl;
}

/*
 * Start the process of crawling for a given thread/process.
 * This function takes as argument a number, which will then be used to
 * determine which thread/process is running and which htmlparser belongs to that.
 * htmlps[threadNumber] will always exist as there are always at least as many
 * htmlps pushed back as threadNumber + 1.
 */
void Webspider::startCrawling(int threadNumber) {
	htmlps.push_back(Htmlparser());
	string url, source, title;
	strSet weblinks;
	unsigned int waitingCounter = 0;
	
	while(downloadsDone < MAXDOWNLOADS) {
		// If we wait for 100 consecutive times, abort.
		if(waitingCounter > 1000) { break; }
		// If we are at the end of the queue, wait a bit for the other threads and then continue.
		if(queue.empty()) { 
			std::this_thread::sleep_for(std::chrono::milliseconds(10)); 
			waitingCounter++;
			continue; 
		}
		url = takeFirstUrl();
		waitingCounter = 0;
		// Check if the url has already been crawled.
		if(url.compare("") == 0 || fs.linkExistRepo(url)) { continue; }
		cout << "Current url = " << url << " from thread number " << threadNumber << endl;
		source = hspfuncs.GetWebPage(url);
		downloadsDone++;
		if(source.empty()) { cout << ":(" << endl; continue; }
		weblinks = htmlps.at(threadNumber).parseLinks(source, url);
		title = htmlps.at(threadNumber).parseTitle(source);
		AppendLinks(weblinks);
		doIndexing(url, source, weblinks, title);
		printf("Downloads done: %d, Max downloads: %d\n", downloadsDone, MAXDOWNLOADS);
	}
}
