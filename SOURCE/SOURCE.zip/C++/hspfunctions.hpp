#ifndef HSPFUNCTIONS_HPP
#define HSPFUNCTIONS_HPP

#include "includes.hpp"

//Struct string to aid function getWebPage(), acts like a string
struct structString {
	char *p;
	size_t l;
};

class Hspfunctions {
	private:
		std::string RemoveTrailingSlashes(std::string orig);
		std::string parseTitle(std::string html);
		std::string getOriginalURL(std::string url);
		
		std::mutex hspMut;
	public:
		HTMLSTREAMPARSER *setHSPAttrs(HTMLSTREAMPARSER *hsp);
		std::string GetWebPage(std::string url);
		std::tuple<std::string, strVec> GetLinksFromWebPage(std::string src, std::string url, HTMLSTREAMPARSER *hsp);
};


#endif
