#include "htmlparser.hpp"

using std::string;

/*
 * Parses all the links, given as <a --something-- href="link" --something-->
 * Every link is checked by checkLink() to make sure cURL can parse it.
 */
strSet Htmlparser::parseLinks(string source, string origUrl) {
	strSet links;
	string currentLink;
	if(source.length() < 5) return {};
	for(size_t i = 0; i < source.length() - 5; i++) {
		currentLink = "";
		if(source[i] == '<' && 
			source[++i] == 'a') {
			while(1) {
				while(source[++i] != 'h' && source[i] != '>') { ; }
				if(source[i] == '>') { break; }
				if(source.substr(i, 4).compare("href") == 0) { 
					i += 5;
					while(source[++i] != '"') { currentLink += source[i]; }
					links.insert(checkLink(currentLink, origUrl));
					break;
				}
			}
		}
	}
	return links;
}

/*
 * Check if the link is usable by cURL, and if not make it so.
 */
string Htmlparser::checkLink(string link, string origUrl) {
	int linkLength = link.length();
	if((linkLength >= 6) && (link.find(".") != string::npos)) {
		string extension = link.substr(linkLength - 6, 5);
		if(extension.find(".jpeg") != string::npos ||
			extension.find(".jpg") != string::npos || 
			extension.find(".pdf") != string::npos || 
			extension.find(".png") != string::npos || 
			extension.find(".svg") != string::npos ||
			link.find("@") != string::npos) { 
			
			printf("Extension not supported of url: %s\n", link.c_str()); 
			return ""; 
		}
	}
	if(link.substr(0, 4).compare("http") == 0) { return link; }
	int origUrlSize = origUrl.length();
	if(link[0] == '/' && origUrl[origUrlSize - 1] == '/') { return origUrl.substr(0, origUrlSize - 1) + link; }
	if(link[0] == '/' || origUrl[origUrlSize - 1] == '/') { return origUrl + link; }
	else { return origUrl + '/' + link; }
}

/*
 * Parse the title manually, as the code in title.c did not work well.
 * First search for character '<' to minimize the use of substr() and
 * compare(), then see if it is the tag "<title>". If so, get the title
 * behind the tag until "</title>" is found, as then the title ends.
 */
string Htmlparser::parseTitle(string source) {
	string token = "";
	bool foundTitle = false;
	for(size_t i = 0; i < source.length(); i++) {
		if(foundTitle) {
			if (source[i] == '<' && source.substr(i, 8).compare("</title>") == 0) { break; }
			token += source[i];
		}
		if(source[i] == '<' && source.substr(i, 7).compare("<title>") == 0) {
			i += 6;
			foundTitle = true;
		}
	}
	return token;
}
