#include "hspfunctions.hpp"

using std::string;

/*
 * Initialise the HTMLSTREAMPARSER which is given
 * as an argument.
 */
HTMLSTREAMPARSER *Hspfunctions::setHSPAttrs(HTMLSTREAMPARSER *hsp) {
	char tag[2];
	char attr[5];
	char val[128]; 	
	html_parser_set_tag_to_lower(hsp, 1);   
	html_parser_set_attr_to_lower(hsp, 1); 
	html_parser_set_tag_buffer(hsp, tag, sizeof(tag));  
	html_parser_set_attr_buffer(hsp, attr, sizeof(attr));    
	html_parser_set_val_buffer(hsp, val, sizeof(val)-1);
	
	return hsp;
}

// Function to initialize a struct string
void initString(struct structString *s) {
	s->l = 0;
	s->p = (char *)malloc(s->l + 1);
	if(s->p == NULL) {
		fprintf(stderr, "Function malloc() failed!\n");
    	exit(EXIT_FAILURE);
	}
	s->p[0] = '\0';
}

// Enables curl to write the html source to a struct string
size_t writeHTML(void *p, size_t s, size_t n, struct structString *t) {
	size_t w = t->l + s * n;
	t->p = (char *)realloc(t->p, w + 1);
	if(t->p == NULL) {
		fprintf(stderr, "Function realloc() failed!\n");
    	exit(EXIT_FAILURE);
	}
	memcpy(t->p + t->l, p, s * n);
	t->p[w] = '\0';
	t->l = w;
	return s * n;
}

/*
 * Use cURL to retrieve the html source of a webpage.
 */
string Hspfunctions::GetWebPage(string url) {
	std::lock_guard<std::mutex> guard(hspMut);
	string html = "";
	try {
		CURL *curl = curl_easy_init();
		char errorBuffer[CURL_ERROR_SIZE];
		CURLcode result;
		if(curl != NULL) {
			struct structString s;
			initString(&s);
			result = curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errorBuffer);
				if(result != CURLE_OK) { printf("Failed to set errorbuffer! [%d]\n", result); }
			result = curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
				if(result != CURLE_OK) { printf("Failed to set url! [%s]\n", errorBuffer); }
			result = curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeHTML);
				if(result != CURLE_OK) { printf("Failed to set writer! [%s]\n", errorBuffer); }
			result = curl_easy_setopt(curl, CURLOPT_WRITEDATA, &s);
				if(result != CURLE_OK) { printf("Failed to set writedata! [%s]\n", errorBuffer); }
			result = curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0);
				if(result != CURLE_OK) { printf("Failed to set ssl! [%s]\n", errorBuffer); }
		   result = curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 2L);
		   	if(result != CURLE_OK) { printf("Failed to set redirect! [%s]\n", errorBuffer); }
		   result = curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, 5000);
		   	if(result != CURLE_OK) { printf("Failed to set timeout! [%s]\n", errorBuffer); }
			result = curl_easy_perform(curl);
				if(result != CURLE_OK) { printf("Failed to perform! [%s]\n", errorBuffer); }
			curl_easy_cleanup(curl);
			html = (string) s.p;
			free(s.p);
		}
		curl_global_cleanup();
	} catch (std::exception& e) {std::cerr << "Exception catched: " << e.what() << std::endl; }
	return html;
}

/*
 * Remove trailing slashes in a string by checking if the 
 * last position holds a slash. For every slash found thereonward
 * a counter is increased, and then this amount is cut off from the string.
 */
string Hspfunctions::RemoveTrailingSlashes(string orig) {
	int start = orig.length(), i;
	for(i = start; orig[i - 1] == '/'; i--) {;}
	return orig.substr(0, orig.length() - (start - i));
}

/*
 * Parse the title manually, as the code in title.c did not work well.
 * First search for character '<' to minimize the use of substr() and
 * compare(), then see if it is the tag "<title>". If so, get the title
 * behind the tag until "</title>" is found, as then the title ends.
 */
string Hspfunctions::parseTitle(string html) {
	string token = "";
	bool foundTitle = false;
	for(size_t i = 0; i < html.length(); i++) {
		if(foundTitle) {
			if (html[i] == '<' && html.substr(i, 8).compare("</title>") == 0) { break; }
			token += html[i];
		}
		if(html[i] == '<' && html.substr(i, 7).compare("<title>") == 0) {
			i += 6;
			foundTitle = true;
		}
	}
	return token;
}

/*
 * Get the original url by taking everything up until the third '/'.
 * The first two of these are in 'http://'.
 * If the url does not contain three slashes, return the whole url.
 */
string Hspfunctions::getOriginalURL(string url) {
	unsigned short slashes = 0;
	for(unsigned int i = 0; i < url.length(); i++) {
		if(url[i] == '/') { slashes++; }
		if(i + 1 == url.length()) { return url; }
		else if(slashes == 3) { return url.substr(0, i); }
	}
	throw;
}

/*
 * Retrieve the links from a webpage using htmlstreamparser.
 * Could be rewritten easily to look better, but as it was
 * mandatory to use this library I did not.
 */
std::tuple<string, strVec> Hspfunctions::GetLinksFromWebPage(string src, string url, HTMLSTREAMPARSER *hsp) {
	strVec links;
	string absLink;
	for (size_t p = 0; p < src.length(); p++) {             
		html_parser_char_parse(hsp, (src.c_str())[p]);
		if (html_parser_cmp_tag(hsp, (char *) "a", 1)) {
			if (html_parser_cmp_attr(hsp, (char *) "href", 4)) {
				if (html_parser_is_in(hsp, HTML_VALUE_ENDED)) { 
					html_parser_val(hsp)[html_parser_val_length(hsp)] = '\0';
					if(strncmp(html_parser_val(hsp), (char *) "http", 4) != 0) {
						absLink = getOriginalURL(url);
						if(html_parser_val(hsp)[0] == '#') { continue; }
						absLink = RemoveTrailingSlashes(absLink);
						if(html_parser_val(hsp)[0] != '/') {absLink += "/";}
						absLink += (string) html_parser_val(hsp);
					} else {
						absLink = (string) html_parser_val(hsp);
					}
					if(absLink.substr(absLink.length() - 4, 4).compare(".pdf") == 0) { continue; }
					links.push_back(absLink);
				}
			}
		}
	}
	;		
	return std::make_tuple(parseTitle(src), links);
}
