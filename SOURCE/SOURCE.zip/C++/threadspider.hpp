#ifndef THREADSPIDER_HPP
#define THREADSPIDER_HPP

#include "includes.hpp"
#include "webspider.hpp"

class Threadspider {
	private:
		int numThreads;
		std::string startingUrl;
		std::vector<std::thread> threads;
		
		Webspider ws;
	public:
		Threadspider(int t, std::string s);
		void startThreading();
};

#endif
